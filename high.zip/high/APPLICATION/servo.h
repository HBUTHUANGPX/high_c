#ifndef _SERVO_H
#define _SERVO_H

#include "fashion_star_uart_servo.h"

//�������ж����ID����ʼ�Ƕ�
#define armServo1  1
#define armServo2 2

#define grabServo 0

#define yawServo 3
#define pitchServo 4

#define Servo1 5
#define Servo2 6
#define Servo3 7
#define Servo4 8

#define xuanzhuan 9

//����Ƕ�

#define xuanzhuan1 46
#define xuanzhuan2 136

#define grabServoOpen 55
#define grabServoClose 75

#define armServo1s -19
#define armServo1e -46
#define armServo2s 117
#define armServo2e 90

#define yawServo1 -4
#define yawServo2 -94

#define pitchServo0 105
#define pitchServo1 70
#define pitchServo2 140

//s�պ�
#define Servo1s -75
#define Servo1e -39
#define Servo2s -40
#define Servo2e 5
#define Servo3s -60
#define Servo3e -10
#define Servo4s -58
#define Servo4e -10

void servo_init(void);
extern Usart_DataTypeDef *servo_usart ;

#endif
