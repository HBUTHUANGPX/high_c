#include "moto.h"
#include "decode.h"
#include "sys_tick.h"
//��ʼ��ֱ����������õ��Ŀ�������
//�ò����õ�������ֱ���������Ҫ��������IO����
//�������Ÿߵ͵�ƽ���г�ʼ��
pin_port_t pp_x;
pin_port_t pp_y;
step_moto_t moto_x;
step_moto_t moto_y;
void motoIOinit()
{
	GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);//ʹ��GPIOFʱ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);//ʹ��GPIOFʱ��

  //GPIOF9,F10��ʼ������
  GPIO_InitStructure.GPIO_Pin = PUL1_PIN|DIR1_PIN | EN1_PIN;//LED0��LED1��ӦIO��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  GPIO_Init(DIR1_PORT, &GPIO_InitStructure);//��ʼ��GPIO
	
	  //GPIOF9,F10��ʼ������
  GPIO_InitStructure.GPIO_Pin =PUL2_PIN| DIR2_PIN | EN2_PIN;//LED0��LED1��ӦIO��
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  GPIO_Init(DIR2_PORT, &GPIO_InitStructure);//��ʼ��GPIO

	GPIO_SetBits(DIR1_PORT,DIR1_PIN);
	GPIO_SetBits(DIR2_PORT,DIR2_PIN);
	GPIO_ResetBits(DIR1_PORT,PUL1_PIN|EN1_PIN);
	GPIO_ResetBits(DIR2_PORT,PUL2_PIN|EN2_PIN);

	pp_x.DIR_Pin  = DIR1_PIN;
	pp_x.DIR_Port = DIR1_PORT;
	pp_x.PUL_Pin  = PUL1_PIN;
	pp_x.PUL_Port = PUL1_PORT;
	pp_x.EN_Pin   = EN1_PIN;
	pp_x.EN_Port  = EN1_PORT;
	
	pp_y.DIR_Pin  = DIR2_PIN;
	pp_y.DIR_Port = DIR2_PORT;
	pp_y.PUL_Pin  = PUL2_PIN;
	pp_y.PUL_Port = PUL2_PORT;
	pp_y.EN_Pin   = EN2_PIN;
	pp_y.EN_Port  = EN2_PORT;
	
	moto_x.ID=1;
	moto_x.derta_move=0;
	moto_x.target_move=0;
	moto_x.true_move=0;
	moto_x.turn=0;
	moto_x.pp=&pp_x;

	moto_y.ID=2;
	moto_y.derta_move=0;
	moto_y.target_move=0;
	moto_y.true_move=0;
	moto_y.turn=0;
	moto_y.pp=&pp_y;
	GPIO_ResetBits(pp_y.EN_Port,pp_y.EN_Pin);	
	GPIO_ResetBits(pp_x.EN_Port,pp_x.EN_Pin);	
}

 void delay_10ns(u16 time)
 {
    while(time--)
    {
    
    }
 }

  void delay_10us(u16 time)
 {
    while(time--)
    {
			delay_10ns(1);// 10000ns=10us
    }
 }
 void delay_10ms(u16 time)
 {
    while(time--)
    {
			delay_10us(1000);
    }
 }

void ctr_moto(){
	moto_x.target_move = PC_UP.PC_UP.x_move;
	moto_y.target_move = PC_UP.PC_UP.y_move;
	
	do{
		ctr_moto_refresh(&moto_x);
		ctr_moto_refresh(&moto_y);
		ctr_moto_set_dir(&moto_x);
		ctr_moto_set_dir(&moto_y);
		ctr_moto_cyc(&moto_x);
		ctr_moto_cyc(&moto_y);
	}while(moto_x.derta_move!=0 || moto_x.derta_move!=0);
}
void ctr_moto_refresh(step_moto_t *step_moto){
	step_moto->derta_move=step_moto->target_move-step_moto->true_move;
	if(step_moto->target_move > step_moto->true_move){
		 step_moto->turn=1;
	 }
	 else if(step_moto->target_move > step_moto->true_move){
		 step_moto->turn=-1;
	 }
	 else{
		 step_moto->turn=0;
	 }
}

void ctr_moto_set_dir(step_moto_t *step_moto){
	if (step_moto->turn==-1){
		GPIO_SetBits(step_moto->pp->DIR_Port,step_moto->pp->DIR_Pin); //set_dir
	}
	else if (step_moto->turn==1){
		GPIO_ResetBits(step_moto->pp->DIR_Port,step_moto->pp->DIR_Pin);
	}
}
void ctr_moto_cyc(step_moto_t *step_moto){
	if (step_moto->turn!=0){
		GPIO_SetBits(step_moto->pp->PUL_Port,step_moto->pp->PUL_Pin);
		SysTick_DelayUs(250);
		GPIO_ResetBits(step_moto->pp->PUL_Port,step_moto->pp->PUL_Pin);
		SysTick_DelayUs(250);
		step_moto->true_move+=step_moto->turn;
		
	}
}
 
 uint16_t x_true_move=0;
 uint16_t y_true_move=0;
 int8_t x_dir=1;
 int8_t y_dir=1;
void moto_ctr(int16_t x_move, int16_t y_move){
	int16_t x_derta_step=x_move*26-x_true_move;
	int16_t y_derta_step=y_move*26-y_true_move;
	uint16_t abs_x=abs(x_derta_step);
	uint16_t abs_y=abs(y_derta_step);
	moto_set_DIR(x_derta_step,1);
	moto_set_DIR(y_derta_step,2);
	if(abs_x>abs_y){
		for(uint16_t i = abs_y;i>0;i--)
		{
			moto_cyc(1);
			moto_cyc(2);
		}
		for(uint16_t i = (abs_x-abs_y);i>0;i--){
			moto_cyc(1);
		}
	}
	else if(abs_x<abs_y){
		for(uint16_t i = abs_x;i>0;i--)
		{
			moto_cyc(1);
			moto_cyc(2);
		}
		for(uint16_t i = (abs_y-abs_x);i>0;i--){
			moto_cyc(2);
		}
	}
	else{
		for(uint16_t i = abs_x;i>0;i--)
		{
			moto_cyc(1);
			moto_cyc(2);
		}
	}
}

void moto_set_DIR(int16_t derta,uint8_t flag){
	if(derta>0){ //������ת
		if(flag==1){ //x���
			GPIO_SetBits(DIR1_PORT,DIR1_PIN);	
			GPIO_ResetBits(EN1_PORT,EN1_PIN);	
			x_dir=1;
		}
		else if (flag==2){ //y���
			GPIO_SetBits(DIR2_PORT,DIR2_PIN);	
			GPIO_ResetBits(EN2_PORT,EN2_PIN);	
			y_dir=1;
	}
}
	else if(derta<0){ //������ת
		if(flag==1){  //x���
			GPIO_ResetBits(DIR1_PORT,DIR1_PIN);	
			GPIO_ResetBits(EN1_PORT,EN1_PIN);
			x_dir=-1;
		}
		else if (flag==2){ //y���
			GPIO_ResetBits(DIR2_PORT,DIR2_PIN);	
			GPIO_ResetBits(EN2_PORT,EN2_PIN);	
			y_dir=-1;
		}
	}
}
void moto_cyc(uint8_t flag){	
	if(flag==1){ //x���
			GPIO_SetBits(PUL1_PORT,PUL1_PIN);
			delay_10ms(1);
			GPIO_ResetBits(PUL1_PORT,PUL1_PIN);
			delay_10ms(1); 
			x_true_move+=x_dir;
	}
	else if(flag==2){ //y���	
			GPIO_SetBits(PUL2_PORT,PUL2_PIN);
			delay_10ms(1);
			GPIO_ResetBits(PUL2_PORT,PUL2_PIN);
			delay_10ms(1);
			y_true_move+=y_dir;
	}	
}
void moto1_positive(){
	u16 Cycle_Num=0;  
		GPIO_SetBits(DIR1_PORT,DIR1_PIN);						 	//PC0����� ˳ʱ�뷽��  DRIVER_DIR
	  GPIO_ResetBits(EN1_PORT,EN1_PIN);						//PC2����� ʹ�����  DRIVER_OE
	
	  for(Cycle_Num=0;Cycle_Num<26;Cycle_Num++)
  {	
		GPIO_SetBits(PUL1_PORT,PUL1_PIN);
    delay_10ms(1);
    GPIO_ResetBits(PUL1_PORT,PUL1_PIN);
    delay_10ms(1); 
	}

}
void moto1_nagitive(){
	u16 Cycle_Num=0;  
	GPIO_ResetBits(DIR1_PORT,DIR1_PIN);						 	//PC0����� ˳ʱ�뷽��  DRIVER_DIR
	  GPIO_ResetBits(EN1_PORT,EN1_PIN);						//PC2����� ʹ�����  DRIVER_OE
	
	  for(Cycle_Num=0;Cycle_Num<26;Cycle_Num++)
  {	
		GPIO_SetBits(PUL1_PORT,PUL1_PIN);
    delay_10ms(1); 
    GPIO_ResetBits(PUL1_PORT,PUL1_PIN);
    delay_10ms(1); 
	}
}


void moto2_positive(){
	u16 Cycle_Num=0;  
	GPIO_SetBits(DIR2_PORT,DIR2_PIN);						 	//PC0����� ˳ʱ�뷽��  DRIVER_DIR
	  GPIO_ResetBits(EN2_PORT,EN2_PIN);						//PC2����� ʹ�����  DRIVER_OE
	
	  for(Cycle_Num=0;Cycle_Num<26;Cycle_Num++)
  {	
		GPIO_SetBits(PUL2_PORT,PUL2_PIN);
    delay_10ms(1); 
    GPIO_ResetBits(PUL2_PORT,PUL2_PIN);
    delay_10ms(1); 
	}//26*2=52ms

}
void moto2_nagitive(){
	u16 Cycle_Num=0;  
	GPIO_ResetBits(DIR2_PORT,DIR2_PIN);						 	//PC0����� ˳ʱ�뷽��  DRIVER_DIR
	  GPIO_ResetBits(EN2_PORT,EN2_PIN);						//PC2����� ʹ�����  DRIVER_OE
	
	  for(Cycle_Num=0;Cycle_Num<26;Cycle_Num++)
  {
		GPIO_SetBits(PUL2_PORT,PUL2_PIN);
    delay_10ms(1); 
    GPIO_ResetBits(PUL2_PORT,PUL2_PIN);
    delay_10ms(1); 
	}
}