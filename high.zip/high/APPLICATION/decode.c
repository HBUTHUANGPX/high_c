#include "decode.h"
#include "usart.h"
#include "moto.h"
#include "servo.h"

state_s s;
// extern state_u state_my;

uint32_t db_mode = 0;

int spd_mode = 0;
int spd[4] = {1, 10, 50, 100};
int speed = 1;

int xuanzhuan_mode=0;

//Usart_DataTypeDef *servo_usart 	= &usart2; // �������߶����Ӧ��USART
int servo_angle[8][2]={ {-75,-39},
												{-40,  5},
												{-60,-10},
												{-58,-10},
//												{55,85},
												{55,90},
												{-19,-46},
												{117,90}, 
												{46,136}
											};
int servo_state[6]={0,0,0,0,0,0};

extern uint8_t tg_flag;
uint8_t tg_flag=0;
int16_t x_move,derta_x_move= (int16_t)0;
int16_t y_move,derta_y_move= (int16_t)0;
void decode_init()
{
//	pc_high_flag=0;

}
void ctr_yaw()
{
	FSUS_SetServoAngleByVelocity(servo_usart,xuanzhuan, \
	servo_angle[7][PC_UP.PC_UP.yaw], \
	300, 250,250,0, 0);
}
void ctr_lift()
{
	FSUS_SetServoAngleByVelocity(servo_usart, armServo1, \
	servo_angle[5][PC_UP.PC_UP.lift], \
	300, 250,250,0, 0);
	FSUS_SetServoAngleByVelocity(servo_usart, armServo2, \
	servo_angle[6][PC_UP.PC_UP.lift], \
	300, 250,250,0, 0);
}
void ctr_grasp()
{
	FSUS_SetServoAngleByVelocity(servo_usart, grabServo, \
	servo_angle[4][PC_UP.PC_UP.grasp], \
	500, 250,250,0, 0);
}
void decode_pc_high()
{
	moto_ctr(PC_UP.PC_UP.x_move,PC_UP.PC_UP.y_move);
	ctr_yaw();
	ctr_lift();
	ctr_grasp();
}
void decodedata()
{
			if (state_my.s.sta_db_1_f_ == 1){
					/* code */
			}
			if (state_my.s.sta_db_2_f_ == 1){
					/* code */
			}
			if (state_my.s.sta_db_3_f_ == 1){
					/* code */
			}
			if (state_my.s.sta_db_4_f_ == 1){
					/* code */
			}
			if (state_my.s.sta_gsp_op_ == 1)
			{
				FSUS_SetServoAngleByVelocity(servo_usart, grabServo, servo_angle[4][servo_state[4]], 2000, 500,150,0, 0);
					//SysTick_DelayMs(200);
				if (servo_state[4]==1)
				{
					servo_state[4]=0;
				}
				else if (servo_state[4]==0)
				{
					servo_state[4]=1;
				}
			}
			if (state_my.s.sta_gsp_gb_ == 1)
			{
				FSUS_SetServoAngleByVelocity(servo_usart, armServo1, servo_angle[5][servo_state[5]], 200, 500,500,0, 0);
				FSUS_SetServoAngleByVelocity(servo_usart, armServo2, servo_angle[6][servo_state[5]], 200, 500,500,0, 0);
					//SysTick_DelayMs(200);
				if (servo_state[5]==1)
				{
					servo_state[5]=0;
				}
				else
				{
					servo_state[5]=1;
				}
			}
			if (state_my.s.sta_tg_gt__ == 1){
					if (tg_flag)
					{
						tg_flag=0;
					}
					else
					{
						tg_flag=1;
					}
			}
			if (state_my.s.sta_tg_gt__ == 1){
					/* code */
			}
			if (state_my.s.sta_x_det__ == 1){
				moto1_positive();
			}
			if (state_my.s.sta_x_down_ == 1){
				moto1_nagitive();
			}
			if (state_my.s.sta_y_det__ == 1)
			{
				moto2_positive();
			}
			if (state_my.s.sta_y_down_ == 1)
			{
				moto2_nagitive();
			}
			if (state_my.s.sta_spd_det == 1)
			{
					if (spd_mode < 3)
					{
							spd_mode += 1;
					}
					else
					{
							spd_mode = 3;
					}
					speed = spd[spd_mode];
			}
			if (state_my.s.sta_spd_dwn == 1)
			{
					if (spd_mode > 0)
					{
							spd_mode -= 1;
					}
					else
					{
							spd_mode = 0;
					}
					speed = spd[spd_mode];
			}
			if (state_my.s.sta_tp_acti == 1){
				
			}
			if (state_my.s.sta_xuanzhuan == 1){
				FSUS_SetServoAngleByVelocity(servo_usart, xuanzhuan, servo_angle[7][xuanzhuan_mode], 700, 500,500,0, 0);
				if (xuanzhuan_mode==0)
				{
					xuanzhuan_mode=1;
				}
				else
				{
					xuanzhuan_mode=0;
				}
			
			}
//			RingBuffer_Reset(usart1.recvBuf);
//			}
//		else
//		{
//			return 0;
//		}
}


